window.__THAR_CONFIG = {
  "userInfo" : {
    "accountId" : "2181275425",
    "userName" : "DavidRoughan",
    "displayName" : "David Roughan"
  },
  "archiveInfo" : {
    "sizeBytes" : "7919858",
    "generationDate" : "2026-06-08T05:04:29.525Z",
    "isPartialArchive" : false,
    "maxPartSizeBytes" : "53687091200"
  },
  "readmeInfo" : {
    "fileName" : "data/README.txt",
    "directory" : "data/",
    "name" : "README.txt"
  },
  "dataTypes" : {
    "account" : {
      "files" : [ {
        "fileName" : "data/account.js",
        "globalName" : "YTD.account.part0",
        "count" : "1"
      } ]
    },
    "accountCreationIp" : {
      "files" : [ {
        "fileName" : "data/account-creation-ip.js",
        "globalName" : "YTD.account_creation_ip.part0",
        "count" : "1"
      } ]
    },
    "accountLabel" : {
      "files" : [ {
        "fileName" : "data/account-label.js",
        "globalName" : "YTD.account_label.part0",
        "count" : "1"
      } ]
    },
    "accountSuspension" : {
      "files" : [ {
        "fileName" : "data/account-suspension.js",
        "globalName" : "YTD.account_suspension.part0",
        "count" : "0"
      } ]
    },
    "accountTimezone" : {
      "files" : [ {
        "fileName" : "data/account-timezone.js",
        "globalName" : "YTD.account_timezone.part0",
        "count" : "1"
      } ]
    },
    "adEngagements" : {
      "files" : [ {
        "fileName" : "data/ad-engagements.js",
        "globalName" : "YTD.ad_engagements.part0",
        "count" : "45"
      } ]
    },
    "adImpressions" : {
      "files" : [ {
        "fileName" : "data/ad-impressions.js",
        "globalName" : "YTD.ad_impressions.part0",
        "count" : "45"
      } ]
    },
    "adMobileConversionsAttributed" : {
      "files" : [ {
        "fileName" : "data/ad-mobile-conversions-attributed.js",
        "globalName" : "YTD.ad_mobile_conversions_attributed.part0",
        "count" : "0"
      } ]
    },
    "adMobileConversionsUnattributed" : {
      "files" : [ {
        "fileName" : "data/ad-mobile-conversions-unattributed.js",
        "globalName" : "YTD.ad_mobile_conversions_unattributed.part0",
        "count" : "0"
      } ]
    },
    "adOnlineConversionsAttributed" : {
      "files" : [ {
        "fileName" : "data/ad-online-conversions-attributed.js",
        "globalName" : "YTD.ad_online_conversions_attributed.part0",
        "count" : "1"
      } ]
    },
    "adOnlineConversionsUnattributed" : {
      "files" : [ {
        "fileName" : "data/ad-online-conversions-unattributed.js",
        "globalName" : "YTD.ad_online_conversions_unattributed.part0",
        "count" : "0"
      } ]
    },
    "adsRevenueSharing" : {
      "files" : [ {
        "fileName" : "data/ads-revenue-sharing.js",
        "globalName" : "YTD.ads_revenue_sharing.part0",
        "count" : "1"
      } ]
    },
    "ageinfo" : {
      "files" : [ {
        "fileName" : "data/ageinfo.js",
        "globalName" : "YTD.ageinfo.part0",
        "count" : "1"
      } ]
    },
    "app" : {
      "files" : [ {
        "fileName" : "data/app.js",
        "globalName" : "YTD.app.part0",
        "count" : "0"
      } ]
    },
    "article" : {
      "files" : [ {
        "fileName" : "data/article.js",
        "globalName" : "YTD.article.part0",
        "count" : "0"
      } ]
    },
    "articleMetadata" : {
      "files" : [ {
        "fileName" : "data/article-metadata.js",
        "globalName" : "YTD.article_metadata.part0",
        "count" : "0"
      } ]
    },
    "block" : {
      "files" : [ {
        "fileName" : "data/block.js",
        "globalName" : "YTD.block.part0",
        "count" : "1942"
      } ]
    },
    "branchLinks" : {
      "files" : [ {
        "fileName" : "data/branch-links.js",
        "globalName" : "YTD.branch_links.part0",
        "count" : "0"
      } ]
    },
    "catalogItem" : {
      "files" : [ {
        "fileName" : "data/catalog-item.js",
        "globalName" : "YTD.catalog_item.part0",
        "count" : "0"
      } ]
    },
    "commerceCatalog" : {
      "files" : [ {
        "fileName" : "data/commerce-catalog.js",
        "globalName" : "YTD.commerce_catalog.part0",
        "count" : "0"
      } ]
    },
    "communityNote" : {
      "files" : [ {
        "fileName" : "data/community-note.js",
        "globalName" : "YTD.community_note.part0",
        "count" : "0"
      } ]
    },
    "communityNoteApiTestNote" : {
      "files" : [ {
        "fileName" : "data/community-note-api-test-note.js",
        "globalName" : "YTD.community_note_api_test_note.part0",
        "count" : "0"
      } ]
    },
    "communityNoteBatsignal" : {
      "files" : [ {
        "fileName" : "data/community-note-batsignal.js",
        "globalName" : "YTD.community_note_batsignal.part0",
        "count" : "0"
      } ]
    },
    "communityNoteRating" : {
      "files" : [ {
        "fileName" : "data/community-note-rating.js",
        "globalName" : "YTD.community_note_rating.part0",
        "count" : "2"
      } ]
    },
    "communityNoteTombstone" : {
      "files" : [ {
        "fileName" : "data/community-note-tombstone.js",
        "globalName" : "YTD.community_note_tombstone.part0",
        "count" : "0"
      } ]
    },
    "communityTweet" : {
      "mediaDirectory" : "data/community_tweet_media",
      "files" : [ {
        "fileName" : "data/community-tweet.js",
        "globalName" : "YTD.community_tweet.part0",
        "count" : "0"
      } ]
    },
    "communityTweetMedia" : {
      "mediaDirectory" : "data/community_tweet_media"
    },
    "connectedApplication" : {
      "files" : [ {
        "fileName" : "data/connected-application.js",
        "globalName" : "YTD.connected_application.part0",
        "count" : "3"
      } ]
    },
    "contact" : {
      "files" : [ {
        "fileName" : "data/contact.js",
        "globalName" : "YTD.contact.part0",
        "count" : "0"
      } ]
    },
    "deletedNoteTweet" : {
      "files" : [ {
        "fileName" : "data/deleted-note-tweet.js",
        "globalName" : "YTD.deleted_note_tweet.part0",
        "count" : "0"
      } ]
    },
    "deletedTweetHeaders" : {
      "files" : [ {
        "fileName" : "data/deleted-tweet-headers.js",
        "globalName" : "YTD.deleted_tweet_headers.part0",
        "count" : "0"
      } ]
    },
    "deletedTweets" : {
      "mediaDirectory" : "data/deleted_tweets_media",
      "files" : [ {
        "fileName" : "data/deleted-tweets.js",
        "globalName" : "YTD.deleted_tweets.part0",
        "count" : "0"
      } ]
    },
    "deletedTweetsMedia" : {
      "mediaDirectory" : "data/deleted_tweets_media"
    },
    "deviceToken" : {
      "files" : [ {
        "fileName" : "data/device-token.js",
        "globalName" : "YTD.device_token.part0",
        "count" : "6"
      } ]
    },
    "directMessageGroupHeaders" : {
      "files" : [ {
        "fileName" : "data/direct-message-group-headers.js",
        "globalName" : "YTD.direct_message_group_headers.part0",
        "count" : "0"
      } ]
    },
    "directMessageHeaders" : {
      "files" : [ {
        "fileName" : "data/direct-message-headers.js",
        "globalName" : "YTD.direct_message_headers.part0",
        "count" : "4"
      } ]
    },
    "directMessageMute" : {
      "files" : [ {
        "fileName" : "data/direct-message-mute.js",
        "globalName" : "YTD.direct_message_mute.part0",
        "count" : "0"
      } ]
    },
    "directMessages" : {
      "mediaDirectory" : "data/direct_messages_media",
      "files" : [ {
        "fileName" : "data/direct-messages.js",
        "globalName" : "YTD.direct_messages.part0",
        "count" : "4"
      } ]
    },
    "directMessagesGroup" : {
      "mediaDirectory" : "data/direct_messages_group_media",
      "files" : [ {
        "fileName" : "data/direct-messages-group.js",
        "globalName" : "YTD.direct_messages_group.part0",
        "count" : "0"
      } ]
    },
    "directMessagesGroupMedia" : {
      "mediaDirectory" : "data/direct_messages_group_media"
    },
    "directMessagesMedia" : {
      "mediaDirectory" : "data/direct_messages_media"
    },
    "emailAddressChange" : {
      "files" : [ {
        "fileName" : "data/email-address-change.js",
        "globalName" : "YTD.email_address_change.part0",
        "count" : "1"
      } ]
    },
    "expandedProfile" : {
      "files" : [ {
        "fileName" : "data/expanded-profile.js",
        "globalName" : "YTD.expanded_profile.part0",
        "count" : "1"
      } ]
    },
    "follower" : {
      "files" : [ {
        "fileName" : "data/follower.js",
        "globalName" : "YTD.follower.part0",
        "count" : "79"
      } ]
    },
    "following" : {
      "files" : [ {
        "fileName" : "data/following.js",
        "globalName" : "YTD.following.part0",
        "count" : "194"
      } ]
    },
    "grokChatItem" : {
      "files" : [ {
        "fileName" : "data/grok-chat-item.js",
        "globalName" : "YTD.grok_chat_item.part0",
        "count" : "12"
      } ]
    },
    "grokChatMedia" : {
      "mediaDirectory" : "data/grok_chat_media"
    },
    "ipAudit" : {
      "files" : [ {
        "fileName" : "data/ip-audit.js",
        "globalName" : "YTD.ip_audit.part0",
        "count" : "285"
      } ]
    },
    "keyRegistry" : {
      "files" : [ {
        "fileName" : "data/key-registry.js",
        "globalName" : "YTD.key_registry.part0",
        "count" : "1"
      } ]
    },
    "like" : {
      "files" : [ {
        "fileName" : "data/like.js",
        "globalName" : "YTD.like.part0",
        "count" : "4435"
      } ]
    },
    "listsCreated" : {
      "files" : [ {
        "fileName" : "data/lists-created.js",
        "globalName" : "YTD.lists_created.part0",
        "count" : "0"
      } ]
    },
    "listsMember" : {
      "files" : [ {
        "fileName" : "data/lists-member.js",
        "globalName" : "YTD.lists_member.part0",
        "count" : "1"
      } ]
    },
    "listsSubscribed" : {
      "files" : [ {
        "fileName" : "data/lists-subscribed.js",
        "globalName" : "YTD.lists_subscribed.part0",
        "count" : "1"
      } ]
    },
    "messageEvent" : {
      "files" : [ {
        "fileName" : "data/message-event.js",
        "globalName" : "YTD.message_event.part0",
        "count" : "4"
      } ]
    },
    "moment" : {
      "mediaDirectory" : "data/moments_media",
      "files" : [ {
        "fileName" : "data/moment.js",
        "globalName" : "YTD.moment.part0",
        "count" : "0"
      } ]
    },
    "momentsMedia" : {
      "mediaDirectory" : "data/moments_media"
    },
    "momentsTweetsMedia" : {
      "mediaDirectory" : "data/moments_tweets_media"
    },
    "mute" : {
      "files" : [ {
        "fileName" : "data/mute.js",
        "globalName" : "YTD.mute.part0",
        "count" : "483"
      } ]
    },
    "niDevices" : {
      "files" : [ {
        "fileName" : "data/ni-devices.js",
        "globalName" : "YTD.ni_devices.part0",
        "count" : "2"
      } ]
    },
    "noteTweet" : {
      "files" : [ {
        "fileName" : "data/note-tweet.js",
        "globalName" : "YTD.note_tweet.part0",
        "count" : "0"
      } ]
    },
    "personalization" : {
      "files" : [ {
        "fileName" : "data/personalization.js",
        "globalName" : "YTD.personalization.part0",
        "count" : "1"
      } ]
    },
    "phoneNumber" : {
      "files" : [ {
        "fileName" : "data/phone-number.js",
        "globalName" : "YTD.phone_number.part0",
        "count" : "0"
      } ]
    },
    "productDrop" : {
      "files" : [ {
        "fileName" : "data/product-drop.js",
        "globalName" : "YTD.product_drop.part0",
        "count" : "0"
      } ]
    },
    "productSet" : {
      "files" : [ {
        "fileName" : "data/product-set.js",
        "globalName" : "YTD.product_set.part0",
        "count" : "0"
      } ]
    },
    "professionalData" : {
      "files" : [ {
        "fileName" : "data/professional-data.js",
        "globalName" : "YTD.professional_data.part0",
        "count" : "0"
      } ]
    },
    "profile" : {
      "mediaDirectory" : "data/profile_media",
      "files" : [ {
        "fileName" : "data/profile.js",
        "globalName" : "YTD.profile.part0",
        "count" : "1"
      } ]
    },
    "profileMedia" : {
      "mediaDirectory" : "data/profile_media"
    },
    "protectedHistory" : {
      "files" : [ {
        "fileName" : "data/protected-history.js",
        "globalName" : "YTD.protected_history.part0",
        "count" : "0"
      } ]
    },
    "replyPrompt" : {
      "files" : [ {
        "fileName" : "data/reply-prompt.js",
        "globalName" : "YTD.reply_prompt.part0",
        "count" : "0"
      } ]
    },
    "savedSearch" : {
      "files" : [ {
        "fileName" : "data/saved-search.js",
        "globalName" : "YTD.saved_search.part0",
        "count" : "0"
      } ]
    },
    "screenNameChange" : {
      "files" : [ {
        "fileName" : "data/screen-name-change.js",
        "globalName" : "YTD.screen_name_change.part0",
        "count" : "0"
      } ]
    },
    "shopModule" : {
      "files" : [ {
        "fileName" : "data/shop-module.js",
        "globalName" : "YTD.shop_module.part0",
        "count" : "0"
      } ]
    },
    "shopifyAccount" : {
      "files" : [ {
        "fileName" : "data/shopify-account.js",
        "globalName" : "YTD.shopify_account.part0",
        "count" : "0"
      } ]
    },
    "smartblock" : {
      "files" : [ {
        "fileName" : "data/smartblock.js",
        "globalName" : "YTD.smartblock.part0",
        "count" : "0"
      } ]
    },
    "sso" : {
      "files" : [ {
        "fileName" : "data/sso.js",
        "globalName" : "YTD.sso.part0",
        "count" : "1"
      } ]
    },
    "tweetHeaders" : {
      "files" : [ {
        "fileName" : "data/tweet-headers.js",
        "globalName" : "YTD.tweet_headers.part0",
        "count" : "1171"
      } ]
    },
    "tweetdeck" : {
      "files" : [ {
        "fileName" : "data/tweetdeck.js",
        "globalName" : "YTD.tweetdeck.part0",
        "count" : "0"
      } ]
    },
    "tweets" : {
      "mediaDirectory" : "data/tweets_media",
      "files" : [ {
        "fileName" : "data/tweets.js",
        "globalName" : "YTD.tweets.part0",
        "count" : "1171"
      } ]
    },
    "tweetsMedia" : {
      "mediaDirectory" : "data/tweets_media"
    },
    "twitterShop" : {
      "files" : [ {
        "fileName" : "data/twitter-shop.js",
        "globalName" : "YTD.twitter_shop.part0",
        "count" : "0"
      } ]
    },
    "verified" : {
      "files" : [ {
        "fileName" : "data/verified.js",
        "globalName" : "YTD.verified.part0",
        "count" : "1"
      } ]
    },
    "verifiedOrganization" : {
      "files" : [ {
        "fileName" : "data/verified-organization.js",
        "globalName" : "YTD.verified_organization.part0",
        "count" : "1"
      } ]
    }
  }
}